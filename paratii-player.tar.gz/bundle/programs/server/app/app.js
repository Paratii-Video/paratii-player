var require = meteorInstall({"imports":{"startup":{"both":{"index.js":function(){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// imports/startup/both/index.js                                                    //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
// Import modules used by both client and server through a single index entry point
// e.g. useraccounts configuration file.                                            // 2
//////////////////////////////////////////////////////////////////////////////////////

}},"server":{"index.js":function(){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// imports/startup/server/index.js                                                  //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
// // Import server startup through a single index entry point                      // 1
// import './fixtures.js';                                                          // 3
// import './register-api.js';                                                      // 4
//////////////////////////////////////////////////////////////////////////////////////

}}},"api":{"users.js":["meteor/mongo","meteor/accounts-base",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// imports/api/users.js                                                             //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
module.export({                                                                     // 1
  createUser: function () {                                                         // 1
    return createUser;                                                              // 1
  }                                                                                 // 1
});                                                                                 // 1
var Mongo = void 0;                                                                 // 1
module.importSync("meteor/mongo", {                                                 // 1
  Mongo: function (v) {                                                             // 1
    Mongo = v;                                                                      // 1
  }                                                                                 // 1
}, 0);                                                                              // 1
var Accounts = void 0;                                                              // 1
module.importSync("meteor/accounts-base", {                                         // 1
  Accounts: function (v) {                                                          // 1
    Accounts = v;                                                                   // 1
  }                                                                                 // 1
}, 1);                                                                              // 1
var createUser = Accounts.createUser;                                               // 6
//////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["/imports/startup/server","/imports/startup/both","../imports/api/users.js",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// server/main.js                                                                   //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
module.importSync("/imports/startup/server");                                       // 1
module.importSync("/imports/startup/both");                                         // 1
module.importSync("../imports/api/users.js");                                       // 1
//////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
